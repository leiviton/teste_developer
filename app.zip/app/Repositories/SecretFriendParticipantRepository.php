<?php

namespace TestDeveloper\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

interface SecretFriendParticipantRepository extends RepositoryInterface
{
    //
}
