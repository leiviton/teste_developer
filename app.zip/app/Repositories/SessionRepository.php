<?php

namespace TestDeveloper\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

interface SessionRepository extends RepositoryInterface
{
    //
}
