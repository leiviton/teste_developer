<?php

namespace TestDeveloper\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

interface ParticipantRepository extends RepositoryInterface
{
    //
}
