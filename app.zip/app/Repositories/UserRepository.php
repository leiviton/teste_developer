<?php

namespace TestDeveloper\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserRepository
 * @package namespace TestDeveloper\Repositories;
 */
interface UserRepository extends RepositoryInterface
{
    //
}
