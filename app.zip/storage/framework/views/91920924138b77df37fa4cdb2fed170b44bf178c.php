<?php $__env->startComponent('mail::message'); ?>

Olá <?php echo e($participant->name); ?>

Segue seu amigo secreto é: <?php echo e($secret->name); ?>, idade: <?php echo e($secret->age); ?>.<br>
Genero: <?php echo e($secret->genre); ?>



Obrigado,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
